
/*
 * Choose Character Display - One CharList for Players 1 and 2.
 * if red chooses archer
 *  blue cannot choose archer
 * 
 * when counter is done
 * 	update 
 * 
 * save characters into CharList array
 * 
 * check column location and color for team placement
 * 
 * when a player turn occurs, use updateList() when a begins and when it is donw;
 */

public class CharList 
{
	Unit[][] unitArray;
	int numPiece; 
	public CharList(int pcs1, int pcs2)
	{
		numPiece = pcs1 + pcs2;
	}
	public void updateList()
	{
		//1st updateList() - check unit existence in MapMemory
		//2nd updateList() - update location or stats of units
		if (isDead(getcharID()) == true)
		{
			
		}
	}
	private Unit getcharID() {
		// TODO Auto-generated method stub
		return null;
	}
	public boolean isDead(Unit charID)
	{
		if( charID.getHP() == 0)
		{
			System.out.println("This unit is dead.");
			return true;
		}
		else
		{
			return false;
		}
	}
}
