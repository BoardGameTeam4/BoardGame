import javax.swing.ImageIcon;
import javax.swing.JButton;

public class MapMemory {
	ImageIcon A = new ImageIcon("unit.jpg");
	static int mapSize;
	JButton[][] MM;
	Unit[][] UM;

	public void addButton (int row, int column, JButton button) {
		MM[row][column] = button;
	}
	
	public MapMemory(int mSize) {
		MM = new JButton[mSize][mSize];
		UM = new Unit[mSize][mSize];
	}

	public void checkMove(int newX, int newY) {
		//if ()
		if (MM[newY][newX] == null) {
			update();
		} else {
			JButton thisButton = MM[newY][newX];
			if (thisButton.getIcon() == null && UM[newY][newX] == null) {
				thisButton.setIcon(A);
				UM[newY][newX] = new Archer();
			}
			else {

				System.out.println("There was a "+UM[newY][newX].getName()+" here.");
				thisButton.setIcon(null);			
				UM[newY][newX] = null;
			}
		}
	}

	public void update() {

	}

	public int getMemX(int locX) {
		return locX;
	}

	public int getMemY(int locY) {
		return locY;
	}

	public int getID(int charID) {
		return charID;
	}

}
