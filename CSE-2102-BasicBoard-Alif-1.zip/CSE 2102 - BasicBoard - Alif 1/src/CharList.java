
public class CharList 
{
	
	int numPiece; 
	public CharList(int pcs1, int pcs2)
	{
		numPiece = pcs1 + pcs2;
	}
	public void updateList()
	{
		if (isDead(getcharID()) == true)
		{
			
		}
	}
	private Unit getcharID() {
		// TODO Auto-generated method stub
		return null;
	}
	public boolean isDead(Unit charID)
	{
		if( charID.getHP() == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
