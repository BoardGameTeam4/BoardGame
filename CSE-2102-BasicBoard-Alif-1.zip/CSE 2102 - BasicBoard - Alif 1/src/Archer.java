import java.util.concurrent.TimeUnit;
public class Archer implements Unit 
{
	int health = 50;
	int dmg = 2; 
	int range = 2;
	int arrowcnt = 12;
	int movement = 2;
	int defense = 1;
	int locY;
	int locX;
	String charstrID = "Archer";
	int charID = 1;
	public void gather()
	{
		arrowcnt = 12;
	}
	public void move() throws InterruptedException 
	{
		
		TimeUnit.SECONDS.sleep(1);
	}
	public void attack() throws InterruptedException
	{
		dmg = getDMG();
		//getTarget HP. 
		//check range of attack
		//check if target defense. 
		//Subtract Attack by defense and store value in a variable.
		//Dependent on class, use accuracy values and or hit markers. 
		//Display the results via text windows
		TimeUnit.SECONDS.sleep(1);
	}
	public void idle() throws InterruptedException 
	{
		TimeUnit.SECONDS.sleep(3);
	}
	public int getX()
	{
		return locX;
	}
	public int getY()
	{
		return locY;
	}
	public String getcharstrID()
	{
		return charstrID;
	}
	public int getcharID()
	{
		return charID; 
	}
	public int getHP()
	{
		return health;
	}
	public int getDMG()
	{
		return dmg;
	}
}
