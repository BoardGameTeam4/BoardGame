import javax.swing.ImageIcon;
import javax.swing.JButton;

public class MapMemory {
	ImageIcon A = new ImageIcon("unit.jpg");
	public Display disp;
	static int mapSize;
	JButton[][] MM;

	public void addButton (int row, int column, JButton button) {
		MM[row][column] = button;
	}
	
	public MapMemory(int mSize) {
		MM = new JButton[mSize][mSize];
	}

	public void checkMove(int newX, int newY) {
		if (MM[newY][newX] == null) {
			update();
		} else {
			JButton thisButton = MM[newY][newX];
			if (thisButton.getIcon() == null) {
				thisButton.setIcon(A);
			}
			else {
				thisButton.setIcon(null);
			}
			//System.out.println("Invalid movement due to Obstruction");
		}
	}

	public void update() {

	}

	public int getMemX(int locX) {
		return locX;
	}

	public int getMemY(int locY) {
		return locY;
	}

	public int getID(int charID) {
		return charID;
	}

}
