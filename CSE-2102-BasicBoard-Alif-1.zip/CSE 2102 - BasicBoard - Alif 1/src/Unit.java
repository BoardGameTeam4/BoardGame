
public interface Unit 
{
	public void move () throws InterruptedException;
	public void attack() throws InterruptedException;
	public void idle() throws InterruptedException;	
	public int getHP();
	public int getcharID();
	public String getcharstrID();
	public int getDMG();
}
