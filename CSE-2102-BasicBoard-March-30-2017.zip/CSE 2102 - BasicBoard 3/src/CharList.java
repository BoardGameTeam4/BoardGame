import javax.swing.ImageIcon;

/*
 * Choose Character Display - One CharList for Players 1 and 2.
 * if red chooses archer
 *  blue cannot choose archer
 * 
 * when counter is done
 * 	update 
 * 
 * save characters into CharList array
 * 
 * check column location and color for team placement
 * 
 * when a player turn occurs, use updateList() when a begins and when it is donw;
 */

public class CharList 
{
	Unit[][] unitArray;
	int numPiece; /*
	public CharList(int pcs1, int pcs2)
	{
		numPiece = pcs1 + pcs2;
	}
	*/
	public CharList() {
		ImageIcon X = new ImageIcon("unit.jpg");
		ImageIcon Y = new ImageIcon("redunit.jpg");
		ImageIcon Z = new ImageIcon("blueunit.jpg");
		
		Archer RED = new Archer();
		RED.set_faction("red");
		RED.return_faction_color();
		Archer BLUE = new Archer();
		BLUE.set_faction("blue");
		unitArray = new Unit[2][4];
		for (int i = 0; i < unitArray[0].length; i++) {
			unitArray[0][i] = RED;
		}
		for (int i = 0; i < unitArray[1].length; i++) {
			unitArray[1][i] = BLUE;
		}
	}
	public void updateList()
	{
		//1st updateList() - check unit existence in MapMemory
		//2nd updateList() - update location or stats of units
		if (isDead(getcharID()) == true)
		{
			
		}
	}
	private Unit getcharID() {
		// TODO Auto-generated method stub
		return null;
	}
	public boolean isDead(Unit charID)
	{
		if( charID.getHP() == 0)
		{
			System.out.println("This unit is dead.");
			return true;
		}
		else
		{
			return false;
		}
	}
}
