import java.util.concurrent.TimeUnit;

import javax.swing.ImageIcon;
public class Archer implements Unit 
{
	public ImageIcon B;
	public int health = 50;
	public int dmg = 2; 
	public int range = 2;
	public int arrowcnt = 12;
	public int movement = 2;
	public int defense = 1;
	public int locY;
	public int locX;
	String charstrID = "Archer";
	public int faction; //1 == red, 2 == blue, 3 == else
	int charID = 1;
	public void setX (int x) {
		locX = x;
	}
	public void setY (int y) {
		locY = y;
	}
	public void set_faction (String name) {
		name = name.toLowerCase();
		if (name.equals("red")) {
			faction = 1;
			B = new ImageIcon("redunit.jpg");
		}
		else if (name.equals("blue")) {
			faction = 2;
			B = new ImageIcon("blueunit.jpg");
		}
		else {
			faction = 3;
			B = new ImageIcon("unit.jpg");
		}
	}
	public int return_faction () {
		return this.faction;
	}
	public ImageIcon return_faction_color () {
		return this.B;
	}
	public void gather()
	{
		arrowcnt = 12;
	}
	public void move() throws InterruptedException 
	{
		
		TimeUnit.SECONDS.sleep(1);
	}
	public void attack() throws InterruptedException
	{
		dmg = getDMG();
		//getTarget HP. 
		//check range of attack
		//check if target defense. 
		//Subtract Attack by defense and store value in a variable.
		//Dependent on class, use accuracy values and or hit markers. 
		//Display the results via text windows
		TimeUnit.SECONDS.sleep(1);
	}
	public void idle() throws InterruptedException 
	{
		TimeUnit.SECONDS.sleep(3);
	}
	public int getX()
	{
		return locX;
	}
	public int getY()
	{
		return locY;
	}
	public String getcharstrID()
	{
		return charstrID;
	}
	public int getcharID()
	{
		return charID; 
	}
	public int getHP()
	{
		return health;
	}
	public int getDMG()
	{
		return dmg;
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Archer";
	}
}
