
public class Main 
{
	static int control = 0;
	public static void main(String arg[])
	{
		Player player = new Player();
		if (control == 0)
		{
			Display pickList = new Display(20, 1, "Character Selection");
			player.pickUnit();
			control = 1;
		}
		Display map = new Display(9, 2, "Map");
		MapMemory memory = new MapMemory(9);
	}
}
