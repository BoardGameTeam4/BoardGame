import javax.swing.ImageIcon;

public abstract class Terrain {
	public ImageIcon II;

	public Terrain (String terrainType) {
		if ((II = new ImageIcon(terrainType)) != null) {
			switch (terrainType) {
			case ("mountain"):{
				
			}
			case ("river"):{
				
			}
			case ("tree"):{
				
			}
			}
		}
	}
}
