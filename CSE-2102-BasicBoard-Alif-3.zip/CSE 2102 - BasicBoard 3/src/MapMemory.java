import javax.swing.ImageIcon;
import javax.swing.JButton;

public class MapMemory {
	ImageIcon X = new ImageIcon("unit.jpg");
	ImageIcon Y = new ImageIcon("redunit.jpg");
	ImageIcon Z = new ImageIcon("blueunit.jpg");
	public CharList CL;
	static int mapSize;
	JButton[][] MM;
	Unit[][] UM;
	int clickIncrement;
	Unit RecentUnit;
	int OldCoordinateX = -999;
	int OldCoordinateY = -999;
	
	public void setCharList (CharList CHAR) {
		CL = CHAR;
		Unit[][] addUnits = CL.unitArray;
		if (MM != null)
			System.out.println("YES");
		UM[1][0] = addUnits[0][0];
		UM[1][2] = addUnits[0][1];
		UM[1][4] = addUnits[0][2];
		UM[1][6] = addUnits[0][3];
		UM[7][2] = addUnits[1][0];
		UM[7][4] = addUnits[1][1];
		UM[7][6] = addUnits[1][2];
		UM[7][8] = addUnits[1][3];

		if (addUnits[0][0] instanceof Archer) {
		MM[1][0].setIcon(addUnits[0][0].return_faction_color());
		MM[1][2].setIcon(addUnits[0][1].return_faction_color());
		MM[1][4].setIcon(addUnits[0][2].return_faction_color());
		MM[1][6].setIcon(addUnits[0][3].return_faction_color());
		MM[7][2].setIcon(addUnits[1][0].return_faction_color());
		MM[7][4].setIcon(addUnits[1][1].return_faction_color());
		MM[7][6].setIcon(addUnits[1][2].return_faction_color());
		MM[7][8].setIcon(addUnits[1][3].return_faction_color());
		}
	}
	
	public void addButton (int row, int column, JButton button) {
		MM[row][column] = button;
	}
	
	public MapMemory(int mSize) {
		MM = new JButton[mSize][mSize];
		UM = new Unit[mSize][mSize];
	}

	public void checkMove(int newX, int newY) {
		if (MM[newY][newX] == null) {
			update();
		} else {
			JButton thisButton = MM[newY][newX];
			if (thisButton.getIcon() != null) {
				System.out.println("Y: "+newY+" X: "+newX);
				UM[newY][newX].return_faction();
				int FACT = UM[newY][newX].return_faction();
				String faction = "";
				switch (FACT){
					case (1):{
						faction = "red";
						break;
					}
					case (2):{
						faction = "blue";
						break;
					}
					case (3):{
						faction = "whatever";
						break;
					}
				}
					System.out.println("There is a "+faction+" "+UM[newY][newX].getName()+" here.");
				RecentUnit = UM[newY][newX];
				this.OldCoordinateX = newX;
				this.OldCoordinateY = newY;
			}
			else {
				if (RecentUnit != null) {
					int FACT = RecentUnit.return_faction();
					String faction = "";
					switch (FACT){
						case (1):{
							faction = "red";
							break;
						}
						case (2):{
							faction = "blue";
							break;
						}
						case (3):{
							faction = "";
							break;
						}
					}
					UM[OldCoordinateY][OldCoordinateX] = null;
					MM[OldCoordinateY][OldCoordinateX].setIcon(null);
					UM[newY][newX] = RecentUnit;
					MM[newY][newX].setIcon(new ImageIcon(faction+"unit.jpg"));
					RecentUnit = null;
					OldCoordinateY = -999;
					OldCoordinateX = -999;
				}
				else {
					System.out.println("You did not click on anything!");
				}
			}
				clickIncrement++;
		}
	}

	public void update() {

	}

	public int getMemX(int locX) {
		return locX;
	}

	public int getMemY(int locY) {
		return locY;
	}

	public int getID(int charID) {
		return charID;
	}

}
