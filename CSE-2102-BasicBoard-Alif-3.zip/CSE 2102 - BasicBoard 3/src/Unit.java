import javax.swing.ImageIcon;

public interface Unit 
{
	public ImageIcon return_faction_color ();
	public int return_faction ();
	public void set_faction(String name);
	public void move () throws InterruptedException;
	public void attack() throws InterruptedException;
	public void idle() throws InterruptedException;	
	public int getHP();
	public int getcharID();
	public String getcharstrID();
	public int getDMG();
	public String getName();
	public int getX();
	public int getY();
	public void setX(int x);
	public void setY(int y);
}
