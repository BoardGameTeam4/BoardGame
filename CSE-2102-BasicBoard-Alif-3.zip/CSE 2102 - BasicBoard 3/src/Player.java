
public class Player 
{
	String[] unitList;
	int pickCnt;
	int[] pieces;
	public Player() {};
	
	public void pickUnit()
	{
		//Requires output of mouse click. 
		//while loop pickCnt < 5/6
		//Then assign to list. 
		//increment pickCnt until 5. 
		//close char selection.
		//else if pickCnt > 5/6
		//System.out.println("Can't pick anymore units");
		
	}
	
	
	
}
