import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Display {
	ImageIcon X = new ImageIcon("unit.jpg");
	ImageIcon Y = new ImageIcon("redunit.jpg");
	ImageIcon Z = new ImageIcon("blueunit.jpg");
	int clickCount;
	static int mapSize;

	public Display(int mSize, int dimension, String header) {
		if (dimension == 1) {
			mSize = mSize / 2;
			mapSize = mSize;
			JFrame disp = new JFrame(header);
			disp.setSize(600, 600);
			disp.setResizable(true);
			disp.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			disp.setLayout(new GridLayout(mapSize, mapSize, 25, 10));
			for (int n = 1; n < (((mapSize) * 2) + 1); n++) {
				JButton newButton = new JButton();
				newButton.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent e) {
						JButton press = (JButton) e.getSource();
						System.out.println(press.getText());
					}
				});
				disp.add(newButton);
			}
			disp.setVisible(true);
		} else if (dimension == 2) {
			MapMemory MM = new MapMemory(mSize);
			CharList CHAR = new CharList();
			mapSize = mSize;
			JFrame disp = new JFrame(header);
			disp.setSize(600, 600);
			disp.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			disp.setLayout(new GridLayout(mapSize, mapSize));
			for (int n = 0; n < mapSize; n++)
				for (int t = 0; t < mapSize; t++) {
					JButton newButton = new JButton();
					newButton.addMouseListener(new MouseAdapter() {
						public void mouseClicked (MouseEvent e) {
							System.out.println((int)(newButton.getX()) + " " + (int)(newButton.getY()));
							MM.checkMove((int)(newButton.getX()/newButton.getWidth()), (int)(newButton.getY()/newButton.getHeight()));
						}
					});
					MM.addButton(n, t, newButton);
					disp.add(newButton);
				}
			MM.setCharList(CHAR);
			disp.setVisible(true);
		}
	}
}
